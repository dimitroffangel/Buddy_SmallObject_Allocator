#ifndef GARBAGE_COLLECTOR_H_GUARD
#define GARGAGE_COLLECTOR_H_GUARD

#include <vector>

#include "SharedHandler.h"
#include "Chunk.h"

class GarbageCollector
{

};



#endif